/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

const { anyApi } = require("convex/server");
module.exports = {
  api: anyApi,
  internal: anyApi,
};
